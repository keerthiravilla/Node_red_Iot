export class IotLiteCircle {
    id: number;
    iotliteradiuse: string;    
}
