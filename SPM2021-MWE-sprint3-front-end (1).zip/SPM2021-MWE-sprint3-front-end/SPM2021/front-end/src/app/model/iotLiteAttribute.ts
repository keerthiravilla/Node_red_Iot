export class IotLiteAttribute {
    id: number;
    description: string;    
}
