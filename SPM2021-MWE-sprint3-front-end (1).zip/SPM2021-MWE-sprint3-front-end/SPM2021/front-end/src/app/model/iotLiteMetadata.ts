export class IotLiteMetadata {
    id: number;
    iotliteMetadataType: string;    
    iotliteMetadataValue: string;    
}
