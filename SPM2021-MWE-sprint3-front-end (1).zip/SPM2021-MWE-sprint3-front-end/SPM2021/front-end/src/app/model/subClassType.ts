export class SubClassType {
    id: number;
    name: string;    
}
