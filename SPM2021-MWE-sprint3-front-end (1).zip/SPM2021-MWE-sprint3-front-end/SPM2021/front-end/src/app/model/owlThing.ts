export class OwlThing {
    id: string;
    name: string;    
}
