export class IotLiteService {
    id: number;
    iotliteInterfaceDescription: string; 
    iotliteendpoint: string;    
    iotliteexposedBy: string;    
    iotliteinterfaceType: string;    
   
}
