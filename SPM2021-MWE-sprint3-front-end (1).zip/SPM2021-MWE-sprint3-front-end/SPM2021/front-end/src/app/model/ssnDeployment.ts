import { GeoPoint } from "./geoPoint";

export class SsnDeployment {
    id: number;
    description: String;
    geoPoint: GeoPoint;    

}
