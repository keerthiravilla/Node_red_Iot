import { SsnSensor } from "./ssnSensor";

export class SsnSensingDevice {
    id: number;
    ssnSensor: SsnSensor;    
}
