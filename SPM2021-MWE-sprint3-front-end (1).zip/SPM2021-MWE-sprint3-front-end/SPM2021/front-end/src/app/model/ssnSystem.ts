export class SsnSystem {
    id: number;
    ssnSubSystem: string;    
}
