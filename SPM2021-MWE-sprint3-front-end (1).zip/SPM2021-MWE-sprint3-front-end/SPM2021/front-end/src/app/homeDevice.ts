import { SubClassType } from "./model/subClassType";


export class HomeDevice {
    id: Number;
    name: String;
    subClassType: SubClassType;

}
