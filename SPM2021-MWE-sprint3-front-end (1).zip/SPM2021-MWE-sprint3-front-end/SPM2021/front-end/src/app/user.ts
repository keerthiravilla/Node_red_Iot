export class User {
    id: number;
    email: string;
    name: string;
    surname: string;
    password: string;
    description: string;
    devicename: string;
    token: string;

}
