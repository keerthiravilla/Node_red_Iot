package com.SPMProject.backend.interfaces;

import com.SPMProject.backend.entityModel.ssnDeployment;
import com.SPMProject.backend.entityModel.ssnDevice;

public interface SsnDeploymentInterface {

}
