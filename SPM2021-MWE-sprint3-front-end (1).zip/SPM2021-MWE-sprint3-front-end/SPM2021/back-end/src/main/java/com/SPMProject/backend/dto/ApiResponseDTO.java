package com.SPMProject.backend.dto;

public class ApiResponseDTO {
    private String message;

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
